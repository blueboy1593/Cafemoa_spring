# README FRONT

여기는 우리가 전하고 싶은 말을 담아보아요!!

```bash
npm install --save reactstrap react react-dom
npm install --save bootstrap
위의 코드로 설치한다.
```

