import React, { Component } from 'react'

export default class FindCafe extends Component {
    render() {
        return (
            <div>
                <h1>여기는 매장찾기 게시판입니당!</h1>
            </div>
        )
    }
}